Extension: Spawn Randomly colored cube at a location 3m from the player's position (represented by a capsule).
To ensure cube spawns above the floor, the random location is chosen from the upper hemisphere around the player's position.
